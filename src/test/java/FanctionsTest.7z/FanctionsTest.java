import lesson4.Fanctions;
import lesson4.TimingExtention;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.ArgumentsProvider;
import org.junit.jupiter.params.provider.ArgumentsSource;
import org.junit.platform.commons.logging.LoggerFactory;

import java.util.logging.Logger;

import static org.assertj.core.api.Assertions.assertThatNullPointerException;
import static org.assertj.core.api.AssertionsForClassTypes.assertThatExceptionOfType;


@ExtendWith(TimingExtention.class)
public class FanctionsTest {
    Fanctions fanctions=new Fanctions();
//    private static Logger logger= (Logger) LoggerFactory.getLogger(FanctionsTest.class);

    @Test
    @Disabled("Площадь треугольника не равна 0")
    void testGivenTriangleAWhenCheckIsNotNull () throws Exception {
        Assertions.assertNotNull(fanctions.triangle(1,2,2));
    }

//    @Test
//    void testTriangleException() {
//        assertThatExceptionOfType(Exception.class).isThrownBy(() -> Fanctions.triangle(0,1,2));
//    }
//
    @Test
    void checkExceptionWhenСalculateTriangle() {
        assertThatNullPointerException().isThrownBy(() -> fanctions.triangle(6,0,2));
    }
////    @AfterEach
//    void tearDown() {
//        logger.info("Выполнится после каждого теста");
//    }
}
